Think.Win1 = function(game){};
Think.Win1.prototype = {
	create: function(){
		this.add.image(0, 0, 'correct');

		this.add.button(125,700, 'continue');
		this.scale.x = .8;
		this.scale.y = .8;
		emitter = this.add.emitter(275, -100);
		emitter.makeParticles(['light3','light4']);
		emitter.start(false, 5000, 30);
		emitter = this.add.emitter(220, -100);
		emitter.makeParticles(['light3','light4']);
		emitter.start(false, 5000, 30);	

		var result = this.add.image(170, 290,'result2');
		var images = this.add.sprite(300, 480,'check');
		images.scale.setTo(3,3);

  //       var scoreText = this.add.text(20, 20, 'Your Score: 0', { font: "40px ComicBook",  fill: 'white'});
  //       scoreText.scale.x = 1.25;
  //       scoreText.scale.y = 1.25;
  //       var bestText = this.add.text(40,80, 'Highscore: '+process.getData(),{font: "40px ComicBook", fill: 'yellow'});
  //       bestText.scale.x = 1.25;
  //       bestText.scale.y = 1.25;
		// this._fontStyle = { font: "40px ComicBook", fill: "yellow", stroke: "#333", strokeThickness: 5, align: "center" };

		this.input.onDown.add(function(){
			// score = process.getData() + 1;
			// localStorage.setItem("gameScore",score);
			console.log("game2 next");

			this.state.start('Game2');
		}, this)
	},

};