Think.Preloader = function(game){
	// define width and height of the game
	Think.GAME_WIDTH = 760;
	Think.GAME_HEIGHT = 425;
};
Think.Preloader.prototype = {
	preload: function(){
		// load images
		this.load.spritesheet('button-play', 'img/button-play.png', 380,127);
		this.load.spritesheet('sign1', 'img/s1.png', 150,150);
		this.load.image('question', 'img/question.png');
		this.load.spritesheet('sign2', 'img/s2.png', 150,150);
		this.load.spritesheet('sign3', 'img/s3.png', 150,150);
		this.load.spritesheet('sign4', 'img/s4.png', 150,150);
		this.load.spritesheet('q1', 'img/q.png', 289,401);
		this.load.spritesheet('idle', 'img/idle.png', 265,341);
		this.load.spritesheet('go', 'img/go.png', 259,90);
		this.load.spritesheet('continue', 'img/continue.png',380,128);
		this.load.spritesheet('playAgain', 'img/playAgain.png', 380,128);
		this.load.spritesheet('restart', 'img/restart.png', 380,128);
		this.load.image('background', 'img/background.png');
		this.load.image('score', 'img/score.png');
		this.load.image('highscore', 'img/highscore.png');
		this.load.image('button-pause', 'img/button-pause.png');
		this.load.image('light1', 'img/light1.png');
		this.load.image('light2', 'img/light2.png');
		this.load.image('light3', 'img/light3.png');
		this.load.image('light4', 'img/light4.png');
		this.load.image('check', 'img/check.png');
		this.load.image('wrong', 'img/close.png');
		this.load.image('title', 'img/title.png');
		this.load.image('result1', 'img/result1.png');
		this.load.image('result2', 'img/result2.png');
		this.load.image('result3', 'img/result3.png');
		this.load.image('result4', 'img/result4.png');
		this.load.image('over1', 'img/over1.png');
		this.load.image('correct', 'img/correct.png');

        this.load.audio('audio', 'audio/bgSound.mp3');
        this.load.audio('win', 'audio/win.mp3');
        this.load.audio('pick', 'audio/poo.mp3');
        this.load.audio('loss', 'audio/loss.mp3');

},

	create: function(){
		// start the MainMenu state
		this.state.start('MainMenu');
	},
};