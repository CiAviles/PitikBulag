Think.Win = function(game){};
Think.Win.prototype = {
	create: function(){
		this.add.image(0, 0, 'correct');

		this.add.button(125,700, 'continue');
		this.scale.x = .8;
		this.scale.y = .8;
		emitter = this.add.emitter(275, -100);
		emitter.makeParticles(['light3','light4']);
		emitter.start(false, 5000, 30);
		emitter = this.add.emitter(220, -100);
		emitter.makeParticles(['light3','light4']);
		emitter.start(false, 5000, 30);		

		var result = this.add.image(170, 290,'result1');
			var images = this.add.sprite(300, 480, 'check');
			images.scale.setTo(3,3);

		this.input.onDown.add(function(){
			console.log("game1 next");
				// localStorage.setItem('gameScore',score+1);
			// this.getData();
			this.state.start('Game1');
		}, this);
	},
		    getData:function(){
		    return (localStorage.getItem("gameScore") == null || localStorage.getItem("gameScore") == "")?0:localStorage.getItem("gameScore");
		    },
};
// this.state.add('Win',Think.Win,false);
	// game.state.start('Win');

