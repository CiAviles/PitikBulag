Think.GameOver7 = function(game){};
Think.GameOver7.prototype = {
	create: function(){
		this.add.sprite(0, 0, 'over1');

		this.add.button(125,550, 'playAgain');
        this.scale.x = .8;
        this.scale.y = .8;

  //       var scoreText = this.add.text(20, 20, 'Your Score: 0', { font: "40px ComicBook",  fill: 'white'});
  //       scoreText.scale.x = 1.25;
  //       scoreText.scale.y = 1.25;
  //       var bestText = this.add.text(40,40, 'Highscore: '+this.getData(),{font: "40px ComicBook", fill: 'yellow'});
  //       bestText.scale.x = 1.25;
  //       bestText.scale.y = 1.25;
		// this._fontStyle = { font: "40px ComicBook", fill: "yellow", stroke: "#333", strokeThickness: 5, align: "center" };

		this.input.onDown.add(function(){
			this.state.start('Game8');
		}, this)
	},


};