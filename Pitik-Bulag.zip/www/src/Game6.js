Think.Game6 = function(game){
};
Think.Game6.prototype = {
	create: function(){
		// start the physics engine
		this.physics.startSystem(Phaser.Physics.ARCADE);
		// display images: background, floor and score
		this.add.sprite(0, 0, 'background');
		this.add.sprite(140, 10, 'score');
		this.add.sprite(340, 10, 'highscore');

		var sprite0 = this.add.sprite(20, 70, 'light2');
		var centerButton = this.add.button(185,185,'question');
		sprite0.alpha = 0;
		this.add.tween(sprite0).to( { alpha: 1 }, 3000, Phaser.Easing.Linear.None, true, 0, 1000, true, Infinity);

		this.add.button(195, 600, 'go', this.question, this, 1, 2);

		this.add.button(550, 10, 'button-pause', this.managePause, this);
		var restart = this.add.button(15, 10, 'restart', this.restart, this);

		restart.scale.setTo(.30,.60);

		var sprite1 = this.add.sprite(10, 720, 'light1');
    	sprite1.alpha = 0;
		this.add.tween(sprite1).to( { alpha: 1 }, 2000, Phaser.Easing.Linear.None, true, 0, 1000, true);
		this.add.button(10, 800, 'sign1', this.sign1, this, 1, 0, 2);

		var sprite2 = this.add.sprite(167, 720, 'light1');
    	sprite2.alpha = 0;
		this.add.tween(sprite2).to( { alpha: 1 }, 2000, Phaser.Easing.Linear.None, true, 0, 1000, true);
		this.add.button(167, 803, 'sign2', this.sign2, this, 1, 0, 2);
		var sprite3 = this.add.sprite(320, 720, 'light1');
    	sprite3.alpha = 0;
		this.add.tween(sprite3).to( { alpha: 1 }, 2000, Phaser.Easing.Linear.None, true, 0, 1000, true);
		this.add.button(320, 798, 'sign3', this.sign3, this, 1, 0, 2);
		var sprite4 = this.add.sprite(480, 720, 'light1');
    	sprite4.alpha = 0;
		this.add.tween(sprite4).to( { alpha: 1 }, 2000, Phaser.Easing.Linear.None, true, 0, 1000, true);
		this.add.button(480, 800, 'sign4', this.sign4, this, 1, 0, 2);
		this._fontStyle = { font: "40px ComicBook", fill: "yellow", stroke: "#333", strokeThickness: 5, align: "center" };
		this.question = this.game.add.group();


	},

   sign1: function(){
		choice = 3;
		localStorage.setItem('choice',choice);
 		var pick = this.add.audio("pick");
	        pick.play();
        var images = this.add.sprite(80, 900, 'check');
			this.input.onDown.add(function(){
				images.destroy();
		}, this);
	},
	
	sign2: function(){
		var images = this.add.sprite(240, 900, 'check');
			choice = 1;
			localStorage.setItem('choice',choice);
		var pick = this.add.audio("pick");
	        pick.play();
	    this.input.onDown.add(function(){
			images.destroy();
		}, this)
	},
	
	sign3: function(){
		var images = this.add.sprite(390, 900, 'check');
			choice = 5;
			localStorage.setItem('choice',choice);
		var pick = this.add.audio("pick");
	        pick.play();
	    this.input.onDown.add(function(){
			images.destroy();
		}, this)
},
	sign4: function(){
		var images = this.add.sprite(550, 900, 'check');
			choice = 7;
			localStorage.setItem('choice',choice);
		var pick = this.add.audio("pick");
	        pick.play();
		this.input.onDown.add(function(){
			images.destroy();
		}, this)
	},
	question: function(){
		var result = this.add.image(195, 190,'result3');
		result = 3;
		var bgAudio = this.add.audio("audio");
        bgAudio.stop();
        // var text = this.add.text(0,0,'Pick First');
       
		if (result == ''+this.getChoice()){
			console.log("TMAA");
			score = 1;
			localStorage.setItem("gameScore",score)
			var images = this.add.sprite(300, 380, 'check');
			images.scale.setTo(3,3);
	        this.state.start('Win6');
			var win = this.add.audio("win");
	        win.play();

		}
		else if(result != ''+this.getChoice()){
			console.log('mali Chem!');
			var images = this.add.sprite(300, 380, 'wrong');
			images.scale.setTo(2.5,2.5);
			this.state.start('GameOver6');

			var loss = this.add.audio("loss");
	        loss.play();

		}
	},
    restart:function (){
		choice = '';
        score = 0;
		    this.state.start('Game7');
    },
	managePause: function(){
		this.game.paused = true;
		var images1 = this.add.sprite(0, 0, 'background');
		var pausedText = this.add.text(100, 250, "Game paused.\nTap anywhere to continue.", this._fontStyle);
		this.input.onDown.add(function(){
				// remove the pause text
				images1.destroy();
				pausedText.destroy();
				// unpause the game
				choice = 0;
				this.game.paused = false;
			}, this);
	},

		update: function(){

		},

	    getChoice:function(){
		    return (localStorage.getItem("choice") == null || localStorage.getItem("choice") == "")?0:localStorage.getItem("choice");
		    },

	    saveData:function(score){
		    localStorage.setItem("gameScore",score);
		    },

	    getData:function(){
		    return (localStorage.getItem("gameScore") == null || localStorage.getItem("gameScore") == "")?0:localStorage.getItem("gameScore");
		    },
};