Think.MainMenu = function(game){};
Think.MainMenu.prototype = {
	create: function(){
		this.add.sprite(0, 0, 'background');
		emitter = this.add.emitter(420, 130);
    	emitter.makeParticles(['light3','light4']);
		 emitter.start(false, 5000, 30);
		 emitter = this.add.emitter(220, 130);
    	emitter.makeParticles(['light3','light4']);
		 emitter.start(false, 5000, 30);
		this.add.button(200,750, 'button-play', this.startGame, this, 1,0, 2);
		this._player = this.add.sprite(5, 600, 'idle');
		this._player.animations.add('idle', [0,1,2], 5, true);
		this._player.animations.play('idle');
		this.add.sprite(120,50, 'title');

		var bgAudio = this.add.audio("audio");
        bgAudio.play();
	},
	startGame: function() {
		// start the Game state
		choice = '';
		// localStorage.setChoice('choice',choice);
		// score = ''+ process.getData();
		// localStorage.setItem('gameScore',score);
		this.state.start('Game');
	}
};